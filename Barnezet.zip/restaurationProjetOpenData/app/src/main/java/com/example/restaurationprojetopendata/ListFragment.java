package com.example.restaurationprojetopendata;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;
import android.app.ProgressDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ListFragment extends Fragment {

    private ArrayList<Restaurant> list;
    private RestaurationAdapter adapter;
    private ListView listView;
    private ProgressDialog progressDialog;
    private boolean isLoading = false;
   private List<Restaurant> restaurantList = new ArrayList<>();

    public ListFragment() {
    }

    public static ListFragment newInstance() {
        return new ListFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_list, container, false);

        progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Chargement des données...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        listView = rootView.findViewById(R.id.lvRestaurant);
        list = new ArrayList<>();

        //WIfi/4G
        ConnectivityManager connectivityManager =
                (ConnectivityManager) requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            connectivityManager.registerDefaultNetworkCallback(networkCallback);
        } else {
            NetworkRequest request = new NetworkRequest.Builder().build();
            connectivityManager.registerNetworkCallback(request, networkCallback);
        }


        // Appeler l'API pour récupérer les restaurants
        ApiRestaurationService service = initRetrofit();
        Call<RestaurationResponse> callRestauration = service.getRestaurationResponse(0);

        callRestauration.enqueue(new Callback<RestaurationResponse>() {
            @Override
            public void onResponse(Call<RestaurationResponse> call, Response<RestaurationResponse> response) {
                progressDialog.dismiss(); // Cacher le loader

                if (response.isSuccessful() && response.body() != null) {
                    RestaurationResponse restauration = response.body();
                    List<Restaurant> restaurants = restauration.getRestaurants();

                    if (restaurants != null && !restaurants.isEmpty()) {
                        list.addAll(restaurants);
                        adapter = new RestaurationAdapter(getContext(), list);
                        listView.setAdapter(adapter);

                        // Appliquer les filtres après avoir ajouté les restaurants à la liste
                        filterRestaurants();

                        // Mettre à jour la liste des restaurants dans MainActivity
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).setRestaurants(list);
                        }
                    } else {
                        Toast.makeText(getContext(), "Aucun restaurant trouvé", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), "Erreur : " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<RestaurationResponse> call, Throwable throwable) {
                progressDialog.dismiss();
                Toast.makeText(getContext(), "Échec de connexion", Toast.LENGTH_SHORT).show();
            }
        });


        listView.setOnItemClickListener((adapterView, view, position, id) -> {
            Intent intent = new Intent(getContext(), infoRestaurationActivity.class);
            Restaurant restaurant = list.get(position);

            intent.putExtra("nom", restaurant.getName() != null ? restaurant.getName() : "Nom inconnu");
            intent.putExtra("type", restaurant.getType() != null ? restaurant.getType() : "Type inconnu");
            intent.putExtra("vegetarien", restaurant.getVegetarian() != null ? restaurant.getVegetarian().toString() : "Non végétarien");
            intent.putExtra("vegan", restaurant.getVegan() != null ? restaurant.getVegan().toString() : "Non vegan");
            intent.putExtra("horaire", restaurant.getOpeningHours() != null ? restaurant.getOpeningHours().toString() : "Horaire inconnu");
            intent.putExtra("accesHandicape", restaurant.getWheelchair() != null ? restaurant.getWheelchair().toString() : "Non accessible aux handicapés");
            intent.putExtra("livraison", restaurant.getDelivery() != null ? restaurant.getDelivery().toString() : "Non livraison");
            intent.putExtra("aEmporter", restaurant.getTakeaway() != null ? restaurant.getTakeaway().toString() : "Non à emporter");
            intent.putExtra("siteWeb", restaurant.getWebsite() != null ? restaurant.getWebsite() : "Site web inconnu");
            intent.putExtra("commune", restaurant.getMetaCodeCom() != null ? restaurant.getMetaCodeCom() : "Commune inconnu");
            intent.putExtra("departement", restaurant.getMetaNameDep() != null ? restaurant.getMetaNameDep() : "Département inconnu");
            intent.putExtra("telephone", restaurant.getPhone() != null ? restaurant.getPhone() : "Téléphone inconnu");

            startActivity(intent);
        });

        // Ajouter un appui long pour ajouter un restaurant aux favoris
        listView.setOnItemLongClickListener((adapterView, view, position, id) -> {
            Restaurant restaurant = list.get(position);

            MainActivity mainActivity = (MainActivity) getActivity();
            if (mainActivity != null) {
                mainActivity.addToFavorites(restaurant);
            }

             RestaurationAdapter adapter = (RestaurationAdapter) listView.getAdapter();
            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }
            return true;
        });

        // Ajouter un OnScrollListener pour détecter le défilement
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (!isLoading) {
                    int totalItemCount = listView.getAdapter().getCount();
                    int lastVisibleItem = listView.getLastVisiblePosition();

                    if (lastVisibleItem == totalItemCount - 1) {
                        isLoading = true;
                        loadMoreData();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });

        return rootView;
    }

    private ApiRestaurationService initRetrofit() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://public.opendatasoft.com/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit.create(ApiRestaurationService.class);
    }

   private void loadMoreData() {
        final int pageNumber = list.size() / 20 + 1;

        ApiRestaurationService service = initRetrofit();
        Call<RestaurationResponse> callRestauration = service.getRestaurationResponse(pageNumber);

        callRestauration.enqueue(new Callback<RestaurationResponse>() {
            @Override
            public void onResponse(Call<RestaurationResponse> call, Response<RestaurationResponse> response) {
                progressDialog.dismiss(); // Cacher le loader

                if (response.isSuccessful() && response.body() != null) {
                    RestaurationResponse restauration = response.body();
                    List<Restaurant> restaurants = restauration.getRestaurants();

                    if (restaurants != null && !restaurants.isEmpty()) {
                        list.addAll(restaurants);

                        adapter = new RestaurationAdapter(getContext(), list);
                        listView.setAdapter(adapter);

                        filterRestaurants();

                    } else {
                        Toast.makeText(getContext(), "Aucun restaurant trouvé", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), "Erreur : " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<RestaurationResponse> call, Throwable throwable) {
                isLoading = false;
                Toast.makeText(getContext(), "Échec de la récupération des données", Toast.LENGTH_SHORT).show();
            }
        });
    }


    //WIfi/4G
    private ConnectivityManager.NetworkCallback networkCallback = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onAvailable(@NonNull Network network) {
            super.onAvailable(network);
            // Le réseau est disponible (Wi-Fi ou 4G)
            Log.d("NetworkCallback", "Connexion disponible !");
            Toast.makeText(getContext(), "Connexion disponible", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onLost(@NonNull Network network) {
            super.onLost(network);
            // La connexion est perdue
            Log.d("NetworkCallback", "Connexion perdue !");
            Toast.makeText(getContext(), "Connexion perdue", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCapabilitiesChanged(@NonNull Network network, @NonNull NetworkCapabilities networkCapabilities) {
            super.onCapabilitiesChanged(network, networkCapabilities);
            boolean unmetered = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED);
            Log.d("NetworkCallback", "Connexion Wi-Fi ? " + unmetered);
            if (unmetered) {
                Toast.makeText(getContext(), "Connexion Wi-Fi", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Connexion 4G", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ConnectivityManager connectivityManager =
                (ConnectivityManager) requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        connectivityManager.unregisterNetworkCallback(networkCallback);
    }


    private void filterRestaurants() {
        boolean filterCafe = getFilterPreference("filter_cafe");
        boolean filterPub = getFilterPreference("filter_pub");
        boolean filterBar = getFilterPreference("filter_bar");
        boolean filterRestaurant = getFilterPreference("filter_restaurant");
        boolean filterFastFood = getFilterPreference("filter_fastFood");
        boolean filterIceCream = getFilterPreference("filter_iceCream");
        boolean filterAll = getFilterPreference("filter_all");

         List<Restaurant> filteredRestaurants = new ArrayList<>();

        for (Restaurant restaurant : list) {
            if ((filterCafe && "cafe".equals(restaurant.getType())) ||
                    (filterPub && "pub".equals(restaurant.getType())) ||
                    (filterBar && "bar".equals(restaurant.getType())) ||
                    (filterFastFood && "fast_food".equals(restaurant.getType())) ||
                    (filterIceCream && "ice_cream".equals(restaurant.getType())) ||
                    (filterAll) ||
                    (filterRestaurant && "restaurant".equals(restaurant.getType()))) {

                filteredRestaurants.add(restaurant);
            }
        }


        adapter.updateList(filteredRestaurants);
    }

    private boolean getFilterPreference(String key) {
        SharedPreferences preferences = getActivity().getSharedPreferences("restaurant_filters", Context.MODE_PRIVATE);
        return preferences.getBoolean(key, false); // valeur par défaut "false"
    }


    public void updateRestaurants(List<Restaurant> filteredRestaurants) {
        this.restaurantList = filteredRestaurants;
    }
}
